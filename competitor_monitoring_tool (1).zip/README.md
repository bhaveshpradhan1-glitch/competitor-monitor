# Competitor Monitoring Alert Tool

A Flask web app for discovering competitor articles, tracking first-seen URLs, detecting likely pricing-page text changes, and optionally emailing a recent-article summary.

## Features
- Crawls a homepage and likely blog/resource links using its own scraper (requests + BeautifulSoup).
- Stores discovered article URLs in SQLite; repeat scans do not re-count already stored URLs as new.
- Extracts title, meta description, and a publish date when exposed by the page.
- Checks likely `/pricing` or `/plans` pages and hashes visible text to flag changes.
- Optional DataForSEO search-volume enrichment and SMTP email summary.
- Handles common failures by showing a message in the UI.

## Run locally
1. Install Python 3.10 or newer.
2. Create and activate a virtual environment (recommended).
3. Run `pip install -r requirements.txt`.
4. Run `python app.py`.
5. Open `http://127.0.0.1:5000`.

## Optional environment variables
- `FLASK_SECRET_KEY`: replace the development default for deployment.
- `DATAFORSEO_LOGIN`, `DATAFORSEO_PASSWORD`: optional DataForSEO API credentials.
- `SMTP_HOST`, `SMTP_PORT` (default 587), `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`: optional email alerts.

## Deployment
Use a Python-compatible host that supports Flask and persistent storage if you want the SQLite database to survive redeploys. Configure the environment variables in the host dashboard. Start command: `gunicorn app:app` (add `gunicorn` to requirements first) or use the host's Python web-service defaults. For production, set a strong `FLASK_SECRET_KEY`.

## Important limitations
- Respect each website's terms, robots.txt, rate limits, and applicable laws. The app refuses a scan if it cannot confirm robots.txt allows the homepage.
- Sites may render articles with JavaScript, block automated requests, or use nonstandard page structures; those may require site-specific handling.
- Keyword enrichment is optional and depends on valid DataForSEO credentials, API access, supported location/language, and available provider data. No volume is fabricated.
- The first scan establishes a baseline for pricing pages. A later scan can report a changed text hash.
- Validate the app against three real competitor domains before submission; no successful live-domain end-to-end test is claimed by this package.
