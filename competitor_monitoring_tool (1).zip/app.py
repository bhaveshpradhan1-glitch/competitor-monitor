import os, re, json, sqlite3, smtplib
from datetime import datetime, timezone
from email.message import EmailMessage
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from flask import Flask, request, render_template_string, flash, redirect, url_for

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "monitor.db")
USER_AGENT = "CompetitorMonitorBot/1.0 (+personal research tool)"
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-this-before-deploying")

HTML = """
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Competitor Monitoring Alert Tool</title>
<style>
body{font-family:system-ui,Arial;margin:0;background:#f4f6fb;color:#172033}.wrap{max-width:1000px;margin:35px auto;padding:0 18px}
.card{background:#fff;border-radius:14px;padding:22px;margin:16px 0;box-shadow:0 3px 14px #13204012}
h1{margin-bottom:4px}.muted{color:#657089}.row{display:flex;gap:10px;flex-wrap:wrap}input[type=url],input[type=text]{padding:12px;border:1px solid #ccd3e0;border-radius:8px;flex:1;min-width:240px}
button{background:#2457d6;color:white;border:0;border-radius:8px;padding:12px 18px;cursor:pointer}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:10px;border-bottom:1px solid #e8ebf2;vertical-align:top}a{color:#2457d6;overflow-wrap:anywhere}.msg{padding:10px;background:#e9f7ed;border-radius:8px;margin:8px 0}.warn{padding:10px;background:#fff4df;border-radius:8px}
small{color:#657089}.pill{display:inline-block;background:#edf1ff;padding:4px 8px;border-radius:20px;font-size:12px}
</style></head><body><div class="wrap">
<h1>Competitor Monitoring Alert Tool</h1><div class="muted">Discover new blog posts and monitor pricing-page changes.</div>
{% with messages = get_flashed_messages() %}{% for m in messages %}<div class="msg">{{m}}</div>{% endfor %}{% endwith %}
<div class="card"><h2>Scan a competitor</h2><form method="post" action="/scan">
<div class="row"><input type="url" name="domain" placeholder="https://example.com" required><button type="submit">Scan website</button></div>
<p><small>Only scan sites you are allowed to access. Respect robots.txt, site terms, and rate limits.</small></p></form>
<form method="post" action="/notify"><h3>Email alert (optional)</h3><div class="row"><input type="text" name="email_to" placeholder="Recipient email"><button type="submit">Send latest summary</button></div></form></div>
<div class="card"><h2>Recent articles found</h2>
{% if articles %}<table><tr><th>Competitor</th><th>Title</th><th>Published</th><th>First seen</th><th>Keyword / volume</th></tr>
{% for a in articles %}<tr><td>{{a.domain}}</td><td><a href="{{a.url}}" target="_blank" rel="noopener">{{a.title}}</a><br><small>{{a.description}}</small></td><td>{{a.published or "Not found"}}</td><td>{{a.first_seen}}</td><td>{{a.keyword or "Not enriched"}}<br><small>{{a.volume or "Volume unavailable"}}</small></td></tr>{% endfor %}</table>{% else %}<p class="muted">No articles stored yet. Scan a competitor domain to begin.</p>{% endif %}
</div>
<div class="card"><h2>Pricing change checks</h2>{% if changes %}<table><tr><th>Competitor</th><th>Page</th><th>Last checked</th><th>Status</th></tr>{% for c in changes %}<tr><td>{{c.domain}}</td><td><a href="{{c.url}}" target="_blank" rel="noopener">{{c.url}}</a></td><td>{{c.checked_at}}</td><td>{{c.status}}</td></tr>{% endfor %}</table>{% else %}<p class="muted">Pricing pages are checked during scans when a likely pricing URL is found.</p>{% endif %}</div>
<div class="card"><h2>Configuration</h2><p class="muted">Optional keyword enrichment: set <code>DATAFORSEO_LOGIN</code> and <code>DATAFORSEO_PASSWORD</code>. Optional email: set <code>SMTP_HOST</code>, <code>SMTP_PORT</code>, <code>SMTP_USER</code>, <code>SMTP_PASSWORD</code>, and <code>SMTP_FROM</code>.</p><p class="warn">Keyword volume is only available when a configured provider returns it. This app does not invent search-volume values.</p></div>
</div></body></html>
"""

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS articles (
      url TEXT PRIMARY KEY, domain TEXT, title TEXT, published TEXT, description TEXT,
      first_seen TEXT, keyword TEXT, volume TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS pricing (
      url TEXT PRIMARY KEY, domain TEXT, content_hash TEXT, checked_at TEXT, status TEXT)""")
    con.commit()
    return con

def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

def clean_text(s):
    return re.sub(r"\s+", " ", s or "").strip()

def fetch(url):
    headers = {"User-Agent": USER_AGENT}
    r = requests.get(url, headers=headers, timeout=15)
    r.raise_for_status()
    return r.text, r.url

def same_host(a, b):
    return urlparse(a).netloc.lower().removeprefix("www.") == urlparse(b).netloc.lower().removeprefix("www.")

def extract_links(soup, base_url):
    out = []
    for a in soup.select("a[href]"):
        u = urljoin(base_url, a.get("href", "").strip())
        p = urlparse(u)
        if p.scheme in ("http", "https") and same_host(u, base_url):
            out.append(u.split("#")[0])
    return list(dict.fromkeys(out))

def robots_allows(base_url):
    try:
        from urllib.robotparser import RobotFileParser
        p = urlparse(base_url)
        robots_url = f"{p.scheme}://{p.netloc}/robots.txt"
        rp = RobotFileParser()
        rp.set_url(robots_url)
        rp.read()
        return rp.can_fetch(USER_AGENT, base_url)
    except Exception:
        # If robots.txt cannot be checked, do not assume permission to crawl.
        return False

def article_data(url):
    html, final_url = fetch(url)
    soup = BeautifulSoup(html, "html.parser")
    title = clean_text((soup.title.string if soup.title else "") or "")
    h1 = soup.find("h1")
    if h1 and clean_text(h1.get_text(" ", strip=True)):
        title = clean_text(h1.get_text(" ", strip=True))
    desc = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
    description = clean_text(desc.get("content", "")) if desc else ""
    published = ""
    for key, value in [
        ("property", "article:published_time"), ("name", "datePublished"),
        ("itemprop", "datePublished"), ("name", "pubdate")
    ]:
        tag = soup.find("meta", attrs={key: value})
        if tag and tag.get("content"):
            published = clean_text(tag["content"])
            break
    if not published:
        time_tag = soup.find("time")
        if time_tag:
            published = clean_text(time_tag.get("datetime") or time_tag.get_text(" ", strip=True))
    return {"url": final_url, "title": title or final_url, "description": description, "published": published}

def maybe_keyword_enrich(title, description):
    # Optional DataForSEO Google Ads search-volume endpoint. If credentials are absent,
    # return empty fields rather than making up volume.
    login = os.getenv("DATAFORSEO_LOGIN")
    password = os.getenv("DATAFORSEO_PASSWORD")
    if not login or not password:
        return "", ""
    keyword = clean_text(title)[:100]
    try:
        r = requests.post(
            "https://api.dataforseo.com/v3/keywords_data/google_ads/search_volume/live",
            auth=(login, password), timeout=20,
            json=[{"keywords": [keyword], "location_code": 2840, "language_code": "en"}]
        )
        r.raise_for_status()
        data = r.json()
        tasks = data.get("tasks") or []
        result = ((tasks[0].get("result") or [{}])[0].get("items") or [{}])[0] if tasks else {}
        volume = result.get("search_volume")
        return keyword, str(volume) if volume is not None else ""
    except Exception:
        return keyword, ""

def find_candidate_pages(domain, homepage_soup, homepage_url):
    links = extract_links(homepage_soup, homepage_url)
    patterns = ("blog", "resource", "article", "news", "insight", "learn")
    return [u for u in links if any(x in urlparse(u).path.lower() for x in patterns)][:12]

def likely_article(url, title, description):
    path = urlparse(url).path.strip("/")
    if not path or path.lower() in {"blog", "blogs", "resources", "resource", "news", "articles", "insights"}:
        return False
    return len(path.split("/")) >= 1 and bool(title or description)

def scan_domain(domain):
    domain = domain.strip()
    if not re.match(r"^https?://", domain, re.I):
        domain = "https://" + domain
    parsed = urlparse(domain)
    if not parsed.netloc:
        raise ValueError("Enter a valid domain, such as https://example.com")
    if not robots_allows(domain):
        raise ValueError("Could not confirm that robots.txt permits crawling this URL. Check the site's robots.txt and access rules before scanning.")
    html, homepage_url = fetch(domain)
    home = BeautifulSoup(html, "html.parser")
    pages = [homepage_url] + find_candidate_pages(domain, home, homepage_url)
    links = extract_links(home, homepage_url)
    # include links likely to be blog/article URLs from the homepage
    article_urls = [u for u in links if any(x in urlparse(u).path.lower() for x in ("blog", "article", "resource", "insight", "news"))]
    for page in pages[1:]:
        try:
            ph, final = fetch(page)
            ps = BeautifulSoup(ph, "html.parser")
            article_urls.extend(extract_links(ps, final))
        except Exception:
            continue
    article_urls = list(dict.fromkeys(article_urls))[:40]
    con = db()
    new_count = 0
    for u in article_urls:
        try:
            if not same_host(u, homepage_url):
                continue
            d = article_data(u)
            if not likely_article(u, d["title"], d["description"]):
                continue
            exists = con.execute("SELECT url FROM articles WHERE url=?", (d["url"],)).fetchone()
            if not exists:
                keyword, volume = maybe_keyword_enrich(d["title"], d["description"])
                con.execute("INSERT OR IGNORE INTO articles VALUES(?,?,?,?,?,?,?,?)",
                    (d["url"], urlparse(homepage_url).netloc, d["title"], d["published"], d["description"], now(), keyword, volume))
                new_count += 1
        except Exception:
            continue
    # detect a likely pricing page from links or common paths
    pricing_candidates = [u for u in links if "pricing" in urlparse(u).path.lower() or "price" in urlparse(u).path.lower()]
    pricing_candidates += [urljoin(homepage_url, "/pricing"), urljoin(homepage_url, "/plans")]
    for u in list(dict.fromkeys(pricing_candidates))[:4]:
        try:
            ph, final = fetch(u)
            text = clean_text(BeautifulSoup(ph, "html.parser").get_text(" ", strip=True))
            digest = __import__("hashlib").sha256(text.encode("utf-8")).hexdigest()
            prev = con.execute("SELECT content_hash FROM pricing WHERE url=?", (final,)).fetchone()
            status = "Changed" if prev and prev["content_hash"] != digest else ("Unchanged" if prev else "Baseline saved")
            con.execute("""INSERT INTO pricing(url,domain,content_hash,checked_at,status) VALUES(?,?,?,?,?)
                ON CONFLICT(url) DO UPDATE SET domain=excluded.domain,content_hash=excluded.content_hash,checked_at=excluded.checked_at,status=excluded.status""",
                (final, urlparse(homepage_url).netloc, digest, now(), status))
        except Exception:
            continue
    con.commit()
    con.close()
    return new_count, urlparse(homepage_url).netloc

def send_email(recipient):
    host = os.getenv("SMTP_HOST")
    user = os.getenv("SMTP_USER")
    password = os.getenv("SMTP_PASSWORD")
    sender = os.getenv("SMTP_FROM", user or "")
    if not (host and user and password and sender and recipient):
        raise ValueError("Email is not configured. Set SMTP_HOST, SMTP_USER, SMTP_PASSWORD, SMTP_FROM, and enter a recipient.")
    con = db()
    rows = con.execute("SELECT domain,title,url,keyword,volume FROM articles ORDER BY first_seen DESC LIMIT 20").fetchall()
    con.close()
    msg = EmailMessage()
    msg["Subject"] = "Competitor monitoring summary"
    msg["From"] = sender
    msg["To"] = recipient
    body = ["Recent articles found:"]
    body += [f"- {r['domain']}: {r['title']} — {r['url']} | keyword={r['keyword'] or 'n/a'} | volume={r['volume'] or 'n/a'}" for r in rows]
    msg.set_content("\n".join(body))
    with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587")), timeout=20) as s:
        s.starttls()
        s.login(user, password)
        s.send_message(msg)

@app.route("/", methods=["GET"])
def index():
    con = db()
    articles = con.execute("SELECT * FROM articles ORDER BY first_seen DESC LIMIT 100").fetchall()
    changes = con.execute("SELECT * FROM pricing ORDER BY checked_at DESC LIMIT 30").fetchall()
    con.close()
    return render_template_string(HTML, articles=articles, changes=changes)

@app.route("/scan", methods=["POST"])
def scan():
    try:
        count, domain = scan_domain(request.form.get("domain", ""))
        flash(f"Scan finished for {domain}. Newly discovered articles saved: {count}.")
    except Exception as e:
        flash(f"Scan could not complete: {e}")
    return redirect(url_for("index"))

@app.route("/notify", methods=["POST"])
def notify():
    try:
        send_email(request.form.get("email_to", "").strip())
        flash("Email summary sent.")
    except Exception as e:
        flash(f"Email alert not sent: {e}")
    return redirect(url_for("index"))

@app.get("/health")
def health():
    return {"status": "ok", "app": "competitor-monitoring-alert-tool"}

if __name__ == "__main__":
    db().close()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
